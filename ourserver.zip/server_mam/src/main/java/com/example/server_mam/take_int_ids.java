package com.example.server_mam;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class take_int_ids {

    //интересы пользователя из бд
    public static ArrayList<Integer> take_int_ids(Integer id,Connection conn){
        ArrayList<Integer> all_ints = new ArrayList<>();
        String req = "SELECT id_interest_tags from profile_interest_tags where id_usr ="+ id +";";
        try {
            Connection con = conn;
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();

                while (data.next()) {
                    all_ints.add(data.getInt(1));
                }
            }
            con.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return all_ints;
    }

}
