package com.example.server_mam;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@RestController
@ComponentScan(basePackages = {"com.example.server_mam"})
@RequestMapping("/api")
public class all_api {
    private final check_coords chck_crds = new check_coords();
    private final Prepareuser usr_prep = new Prepareuser();


    //регистрация пользователя
    @GetMapping("/reg")
    private Integer reg(@RequestParam("name") String name, @RequestParam("age") String age,
                        @RequestParam("log") String login, @RequestParam("pwd") String password,
                        @RequestParam("hg") String height, @RequestParam("ab") String about,
                        @RequestParam("sex") Boolean sex, @RequestParam("ct") String city,
                        @RequestParam("gl") String goals) {
        Integer iflog = 0;
        Integer id = 0;

        try {
            Connection con = for_sql.for_sql();

            Statement stmt = con.createStatement();
            String req = "SELECT EXISTS(SELECT login_ from profile where login_ = '" + login + "');";
            Statement stm = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet data = stm.executeQuery(req);

            data.beforeFirst();
            if (data.next()) {
                iflog = data.getBoolean(1) ? 1 : 0;
            }
            if (iflog == 0) {

                String sql = "INSERT INTO profile (nickname, age, login_, password_, height, about, sex, city, goals) " + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement preparedStatement = con.prepareStatement(sql);
                preparedStatement.setString(1, name);
                preparedStatement.setInt(2, Integer.parseInt(age));
                preparedStatement.setString(3, login);
                preparedStatement.setString(4, password);
                preparedStatement.setInt(5, Integer.parseInt(height));
                preparedStatement.setString(6, about);
                preparedStatement.setBoolean(7, sex);
                preparedStatement.setString(8, city);
                preparedStatement.setString(9, goals);
                int raws = preparedStatement.executeUpdate();
                req = "SELECT id from profile where login_ = '" + login + "';";
                data = stm.executeQuery(req);
                data.beforeFirst();
                if (data.next()) {
                    id = data.getInt(1);
                }
                stmt.close();
                con.close();

                chck_crds.enter_cords_into_tabel(id, for_sql.for_sql());
                return 1;
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 2;
        }

    }


    //проверка входа
    @GetMapping("/log")
    public Integer log(@RequestParam("pwd") String pwd, @RequestParam("log") String log) {
        Integer iflog = 0;
        String sql = "SELECT EXISTS(SELECT login_, password_ from profile where password_ = '" + pwd + "' and login_ = '" + log + "');";

        try {
            Connection con = for_sql.for_sql();
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(sql);

                data.beforeFirst();

                if (data.next()) {
                    iflog = data.getBoolean(1) ? 1 : 0;
                }
                if (iflog != 0) {
                    sql = "SELECT id from profile where password_ = '" + pwd + "' and login_ = '" + log + "';";
                    data = stm.executeQuery(sql);
                    data.beforeFirst();
                    if (data.next()) {
                        return data.getInt(1);
                    }
                } else {
                    return iflog;
                }
                con.close();
            }
        } catch (SQLException e) {
            return 0;
        }
        return 0;
    }


    //смена личной информации
    @GetMapping("/change_about")
    public Integer change_about(@RequestParam("id") Integer id, @RequestParam("about") String about) {
        try {
            Connection con = for_sql.for_sql();
            Statement stm = con.createStatement();
            String sql = "UPDATE profile SET about = ? WHERE id = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, about);
            preparedStatement.setInt(2, id);
            int raws = preparedStatement.executeUpdate();
            stm.close();
            con.close();
            return raws;
        } catch (Exception e) {
            return 0;
        }
    }


    //смена возраста
    @GetMapping("/change_age")
    public Integer change_age(@RequestParam("id") Integer id, @RequestParam("age") Integer age) {
        try {
            Connection con = for_sql.for_sql();
            Statement stm = con.createStatement();
            String sql = "UPDATE profile SET age = ? WHERE id = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setInt(1, age);
            preparedStatement.setInt(2, id);
            int raws = preparedStatement.executeUpdate();
            stm.close();
            con.close();
            return raws;
        } catch (Exception e) {
            return 0;
        }
    }


    //смена города
    @GetMapping("/change_city")
    public Integer change_city(@RequestParam("id") Integer id, @RequestParam("city") String city) {
        try {
            Connection con = for_sql.for_sql();
            Statement stm = con.createStatement();
            String sql = "UPDATE profile SET city = ? WHERE id = ?";
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, city);
            preparedStatement.setInt(2, id);
            int raws = preparedStatement.executeUpdate();
            stm.close();
            con.close();
            return raws;
        } catch (Exception e) {
            return 0;
        }
    }


    //смена интересов
    @GetMapping("/change_int")
    public Integer change_int(@RequestParam("int1") String int1, @RequestParam("int2") String int2, @RequestParam("int3")
    String int3, @RequestParam("int4") String int4, @RequestParam("int5") String int5, @RequestParam("id") Integer id) {

        ArrayList<Integer> ins = new ArrayList<>();
        ArrayList<Integer> all_id_tbl = new ArrayList<>();

        String sql = "SELECT id_interest_tags FROM interest_tags WHERE interest_tag ='" + int1 + "';";
        try {
            Connection con = for_sql.for_sql();
            if (con != null) {
                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet data = stm.executeQuery(sql);

                data.beforeFirst();
                if (data.next()) {
                    ins.add(data.getInt(1));
                }
                sql = "SELECT id_interest_tags FROM interest_tags WHERE interest_tag ='" + int2 + "';";
                data = stm.executeQuery(sql);

                data.beforeFirst();
                if (data.next()) {
                    ins.add(data.getInt(1));

                }
                sql = "SELECT id_interest_tags FROM interest_tags WHERE interest_tag ='" + int3 + "';";
                data = stm.executeQuery(sql);

                data.beforeFirst();
                if (data.next()) {
                    ins.add(data.getInt(1));
                }
                sql = "SELECT id_interest_tags FROM interest_tags WHERE interest_tag ='" + int4 + "';";
                data = stm.executeQuery(sql);

                data.beforeFirst();
                if (data.next()) {
                    ins.add(data.getInt(1));
                }
                sql = "SELECT id_interest_tags FROM interest_tags WHERE interest_tag ='" + int5 + "';";
                data = stm.executeQuery(sql);

                data.beforeFirst();
                if (data.next()) {
                    ins.add(data.getInt(1));
                }

                sql = "SELECT id FROM profile_interest_tags WHERE id_usr ='" + id + "';";
                data = stm.executeQuery(sql);
                data.beforeFirst();
                while (data.next()) {
                    all_id_tbl.add(data.getInt(1));
                }
                int raws = 0;
                PreparedStatement preparedStatement;
                for (int i = 0; i < all_id_tbl.size(); i++) {
                    sql = "Update  profile_interest_tags SET id_interest_tags=" + ins.get(i) + " where id= " + all_id_tbl.get(i);
                    preparedStatement = con.prepareStatement(sql);
                    raws *= preparedStatement.executeUpdate();
                }
                con.close();
                stm.close();
                return raws;
            }
        } catch (Exception e) {
            return 0;
        }
        return 0;
    }


    //смена имени
    @GetMapping("/change_name")
    public Integer change_name(@RequestParam("id") Integer id, @RequestParam("name") String name) {
        String sql = "UPDATE profile SET nickname = ? WHERE id = ?";
        try {
            Connection con = for_sql.for_sql();
            Statement stm = con.createStatement();
            PreparedStatement preparedStatement = con.prepareStatement(sql);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, id);
            int raws = preparedStatement.executeUpdate();
            stm.close();
            con.close();
            return raws;
        } catch (Exception e) {
            return 0;
        }
    }


    //расстояние между пользователями
    @GetMapping("/ret_dist")
    public String ret_dist(@RequestParam("id1") Integer id1, @RequestParam("id2") Integer id2) {
        return Double.toString(chck_crds.cords_tortrn(id1, id2, for_sql.for_sql()));
    }


    //выгрузка фото
    @GetMapping("/download")
    public ResponseEntity<Object> downloadFile(@RequestParam("id") String id_user) throws IOException {
        String filename = "";
        try {
            filename = "userphoto/"+id_user + ".jpg";
            File file = new File(filename);
            InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
            HttpHeaders headers = new HttpHeaders();

            headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
            headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
            headers.add("Pragma", "no-cache");
            headers.add("Expires", "0");

            ResponseEntity<Object>
                    responseEntity = ResponseEntity.ok().headers(headers).contentLength(
                    file.length()).contentType(MediaType.parseMediaType("application/txt")).body(resource);

            return responseEntity;
        }
        catch (Exception e) {
            filename = "userphoto/nophoto.jpg";
            File file = new File(filename);
            InputStreamResource resource = new InputStreamResource(new FileInputStream(file));
            HttpHeaders headers = new HttpHeaders();
            headers.add("Content-Disposition", String.format("attachment; filename=\"%s\"", file.getName()));
            headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
            headers.add("Pragma", "no-cache");
            headers.add("Expires", "0");

            ResponseEntity<Object>
                    responseEntity = ResponseEntity.ok().headers(headers).contentLength(
                    file.length()).contentType(MediaType.parseMediaType("application/txt")).body(resource);
            return responseEntity;

        }
    }


    //загрузка фото
    @RequestMapping(value = "/upload", method = RequestMethod.POST,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Integer fileUpload(@RequestParam("file") MultipartFile file) {

        try {
            File convertFile = new File(file.getOriginalFilename());
            convertFile.createNewFile();
            FileOutputStream fout = new FileOutputStream(convertFile);
            fout.write(file.getBytes());
            fout.close();

            return 1;
        } catch (Exception e) {
            return 0;
        }
    }


    //данные о пользователе
    @GetMapping(value = "/usr_return", produces = MediaType.APPLICATION_JSON_VALUE)
    private User usr_data_return(@RequestParam("id") String id_usr) {
        return usr_prep.returndata(id_usr, for_sql.for_sql());
    }


    //интересы пользователя
    @GetMapping("/take_user_interest")
    public String[] take_user_interest(@RequestParam("id") Integer id) {

        List<String> a = new ArrayList<String>();
        String req = "SELECT interest_tags.interest_tag\n" +
                "from profile_interest_tags\n" +
                "         inner join interest_tags on interest_tags.id_interest_tags = profile_interest_tags.id_interest_tags\n" +
                "where id_usr = " + id + ";";
        try {
            Connection con = for_sql.for_sql();
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();

                while (data.next()) {
                    a.add(data.getString(1));
                }

                if (a.size() != 0) {
                    String[] strings = new String[a.size()];
                    a.toArray(strings);

                    return strings;
                }
            }

            for (int i = 0; i < 5; i++) {
                a.add("err");
            }

            String[] strings = new String[a.size()];
            a.toArray(strings);

            return strings;
        } catch (Exception e) {
            for (int i = 0; i < 5; i++) {
                a.add("err");
            }

            String[] strings = new String[a.size()];
            a.toArray(strings);

            return strings;

        }

    }


    //язык пользователя
    @GetMapping("/ret_lang")
    public String ret_lang(@RequestParam("id") Integer id) {
        String reslt = "";
        try {
            Connection con = for_sql.for_sql();
            String req = "SELECT languages.language from profile_language inner join languages on profile_language.id_language = languages.id_language where id_usr =" + id + ";";
            Statement stm = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet data = stm.executeQuery(req);
            data.beforeFirst();
            if (data.next()) {
                reslt = data.getString(1);
            }
            return reslt;
        } catch (Exception e) {
            return "Тарабарский";
        }
    }


    //пользователи подходящие по интересам
    @GetMapping("/takelistusers")
    public Integer[] takelistusers(@RequestParam("id") Integer id) {
        ArrayList<Integer> list_usrs = take_int_ids.take_int_ids(id, for_sql.for_sql());
        ArrayList<Integer> a = new ArrayList<>();
        String req = "SELECT id_usr from profile_interest_tags " +
                "where id_interest_tags in " +
                "(" + list_usrs.get(0) + "," + list_usrs.get(1) + "," + list_usrs.get(2) + "," + list_usrs.get(3) + "," + list_usrs.get(4) + ") " +
                "group by id_usr order by Count(id_interest_tags) desc";

        try {
            Connection con = for_sql.for_sql();
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();
                if (data.next()) {
                    while (data.next()) {
                        a.add(data.getInt(1));
                    }
                }
                Integer[] strings = new Integer[a.size()];
                a.toArray(strings);

                return strings;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new Integer[]{};
        }
        return null;
    }

    //добавить симпатию
    @GetMapping("/fillmatch")
    public Integer fillmatch(@RequestParam("id1") Integer id1, @RequestParam("id2") Integer id2) {
        Integer iflog = 0;
        try {
            Connection con = for_sql.for_sql();
            Statement stmt = con.createStatement();
            String req = "SELECT EXISTS(SELECT id_match from match_table where id_user_1 = '" + id1 + "'and id_user_2 = '" + id2 + "');";
            Statement stm = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet data = stm.executeQuery(req);
            data.beforeFirst();
            if (data.next()) {
                iflog = data.getBoolean(1) ? 1 : 0;
            }
            if (iflog == 0) {
                String sql = "INSERT INTO match_table (id_user_1, id_user_2) VALUES (?, ?)";
                PreparedStatement preparedStatement = con.prepareStatement(sql);
                preparedStatement.setInt(1, id1);
                preparedStatement.setInt(2, id2);
                int raws = preparedStatement.executeUpdate();
                stmt.close();
                con.close();
                return raws;
            } else {
                return 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return 2;
        }
    }


    //взаимная симпатия
    @GetMapping("/return_matches")
    public Integer[] rtrn(@RequestParam("id") Integer id) {
        List<Integer> a = new ArrayList<>();
        String req = "select t1.id_user_2\n" +
                "from match_table t1\n" +
                "         join match_table t2\n" +
                "              on t1.id_user_1 = t2.id_user_2 and t1.id_user_2 = t2.id_user_1 where t1.id_user_1=" + Integer.toString(id) + ";";
        try {
            Connection con = for_sql.for_sql();
            if (con != null) {
                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();

                while (data.next()) {
                    a.add(data.getInt(1));
                }

                Integer[] strings = new Integer[a.size()];
                a.toArray(strings);
                return strings;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new Integer[]{};
        }
        return null;
    }


    //список интересов
    @GetMapping("/takeinterests")
    public String[] takeinterests() {
        List<String> a = new ArrayList<>();
        String req = "SELECT interest_tag from interest_tags ";
        try {
            Connection con = for_sql.for_sql();
            if (con != null) {
                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();

                while (data.next()) {
                    a.add(data.getString(1));
                }

                String[] strings = new String[a.size()];
                a.toArray(strings);
                return strings;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new String[]{e.toString()};
        }
        return null;
    }


    //список языков
    @GetMapping("/takelanguage")
    public String[] takelanguage() {
        List<String> a = new ArrayList<String>();
        String req = "SELECT language from languages ";
        try {
            Connection con = for_sql.for_sql();
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);
                data.beforeFirst();

                while (data.next()) {
                    a.add(data.getString(1));
                }

                String[] strings = new String[a.size()];
                a.toArray(strings);
                return strings;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return new String[]{e.toString()};
        }
        return null;
    }


}
