package com.example.server_mam;

import java.sql.*;

public class Prepareuser {
    private User usr = new User();

    //заполнение пользователя
    public User make_user(ResultSet data) {

        try {
            usr.setId(data.getInt(1));
            usr.setName(data.getString(2));
            usr.setAge(data.getInt(3));
            usr.setLogin( data.getString(4));
            usr.setPassword( data.getString(5));
            usr.setHeight( data.getString(6));
            usr.setAbout( data.getString(7));
            usr.setSex( data.getBoolean(8));
            usr.setCity( data.getString(9));
            usr.setGoals( data.getString(10));

            return usr;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    //данные из бд о пользователе
    public User returndata(String id_usr, Connection conn){
        try {
            Connection con = conn;
            String req = "SELECT * from profile where id = " + id_usr + ";";
            Statement stm = con.createStatement(
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet data = stm.executeQuery(req);
            if (data.next()) {
                return make_user(data);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
