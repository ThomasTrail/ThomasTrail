package com.example.server_mam;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.sql.*;
import java.util.ArrayList;

public class check_coords {

    //расчет расстояния между точками
    public double count(ArrayList<Double> xy, ArrayList<Double> xy2) {
        // Calculate the difference between x-coordinates and y-coordinates
        double earthRadius = 6371; // Earth's radius in kilometers

        // Convert latitude and longitude to radians
        double dLat = Math.toRadians(xy2.get(0) - xy.get(0));
        double dLon = Math.toRadians(xy2.get(1) - xy.get(1));

        // Apply the Haversine formula
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(xy.get(0))) * Math.cos(Math.toRadians(xy2.get(0)))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        // Calculate the distance
        double distance = earthRadius * c;

        return distance;
    }

    //возвращение расстояния
    public Double cords_tortrn(Integer id1, Integer id2, Connection conn){
        return count(return_coords(id1,conn),return_coords(id2,conn));}

    //добавление координат по городу в бд
    public Integer enter_cords_into_tabel(Integer user_id, Connection conn) {

        String url_cords = "";
        String ct_name = null;
        double x = 0, y = 0;
        String req = "SELECT city from profile where id = '" + Integer.toString(user_id) + "'";
        System.out.println(req);
        try {
            Connection con = conn;
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);

                data.beforeFirst();

                if (data.next()) {
                    ct_name = data.getString(1);
                }
                System.out.println(ct_name);
                try {
                    url_cords = "https://geocode-maps.yandex.ru/1.x?geocode=" + URLEncoder.encode((ct_name), "UTF-8") + URLEncoder.encode((",+Россия"), "UTF-8") + "&apikey=43d38fa3-89df-4c40-8fc1-db8a25379514&results=1&format=json";
                    String res = ReadFromWeb.readFromWeb(url_cords);
                    JSONObject jsonObject = new JSONObject(res);
                    JSONObject responseObj = jsonObject.getJSONObject("response");
                    JSONObject geoObjectCollectionObj = responseObj.getJSONObject("GeoObjectCollection");
                    JSONArray featureMemberArr = geoObjectCollectionObj.getJSONArray("featureMember");
                    JSONObject geoObjectObj = featureMemberArr.getJSONObject(0).getJSONObject("GeoObject");
                    JSONObject pointObj = geoObjectObj.getJSONObject("Point");
                    String posValue = pointObj.getString("pos");
                    String[] posArray = posValue.split(" ");
                    x = Double.parseDouble(posArray[0]);
                    y = Double.parseDouble(posArray[1]);
                    System.out.println("x: " + x);
                    System.out.println("y: " + y);
                    String sql = "UPDATE profile SET coord1 = ?, coord2 = ? WHERE id = ?";
                    PreparedStatement preparedStatement = con.prepareStatement(sql);
                    preparedStatement.setDouble(1, y);
                    preparedStatement.setDouble(2, x);
                    preparedStatement.setInt(3, user_id);
                    int raws = preparedStatement.executeUpdate();
                    stm.close();
                    con.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                assert con != null;
                con.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    //возвращение координат пользователя
    public ArrayList<Double> return_coords(Integer id, Connection conn) {
        ArrayList<Double> all_cords = new ArrayList<>();
        String req = "SELECT coord1,coord2 from profile where id = '" + Integer.toString(id) + "'";
        try {
            Connection con = conn;
            if (con != null) {

                Statement stm = con.createStatement(
                        ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

                ResultSet data = stm.executeQuery(req);

                data.beforeFirst();

                if (data.next()) {
                    all_cords.add(data.getDouble(1));
                    all_cords.add(data.getDouble(2));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(all_cords);
        return all_cords;
    }
}
