package com.example.server_mam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;


public class ReadFromWeb {

    //для yamapaip
    public static String readFromWeb(String webURL) throws IOException {
        String start = "";
        System.out.println(start+webURL);
        URL url = new URL(start+webURL);
        InputStream is =  url.openStream();
        try( BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            line = br.readLine();
            System.out.println(line);
            return line;
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
            throw new MalformedURLException("URL is malformed!!");
        }
        catch (IOException e) {
            e.printStackTrace();
            throw new IOException();
        }

    }
}