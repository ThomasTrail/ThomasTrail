package com.example.server_mam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class for_sql {

    //для бд
    public static Connection for_sql(){
        String DB_URL = "jdbc:postgresql://26.157.130.164:5432/postgres";
        String USERNAME = "x";
        String PASSWORD = "1111";
        try {
            Connection con = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
            return con;
        } catch (SQLException e) {
            return null;
        }

    }
}
