import GUI_main.loginpage;

import javax.swing.*;
import java.awt.*;

public class Main {

    public static void main(String[] args) {
        loginpage lp = new loginpage();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        int width = (int) ((int)screenSize.width*(float)(35/96));
        int height = (int) ((int)screenSize.height*(float)(10/12));
        System.out.println(width+"x"+height+" "+(35/12));
        lp.setSize(700, 900);
        int x = (screenSize.width - lp.getWidth()) / 2;
        int y = (screenSize.height - lp.getHeight()) / 2;
        lp.setLocation(x, y);
        //lp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //lp.setVisible(true);
    }
}
//2073600
//0 3472222

