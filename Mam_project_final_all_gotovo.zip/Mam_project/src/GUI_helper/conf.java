package GUI_helper;

public class conf {
    public static User usr = new User();
}
