package GUI_helper;

import java.util.ArrayList;
import java.util.List;

public class User {
    public Integer id;
    public String name;
    public Integer age;
    public String login;
    public String password;
    public String height;
    public String about;
    public Boolean sex;
    public String city;
    public String goals;
    public String language;
    public String distance;
    public List<String> interests;
    public List<String> allUsers;

    public void setAllUsers(List<String> allUsers) {
        this.allUsers = allUsers;
    }

    public String getName() {
        return name;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public void setInterests(List<String> interests) {
        this.interests = interests;
    }

    public Integer getAge() {
        return age;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }

    public String getHeight() {
        return height;
    }

    public String getAbout() {
        return about;
    }

    public Boolean getSex() {
        return sex;
    }

    public String getCity() {
        return city;
    }

    public String getGoals() {
        return goals;
    }

    public void setId(Integer id) {
        this.id = id;
        System.out.println(id);
    }

    public Integer getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public void setSex(Boolean sex) {
        this.sex = sex;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setGoals(String goals) {
        this.goals = goals;
    }

    @Override
    public String toString() {
        return "MatchUser{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", age=" + age +
                ", height='" + height + '\'' +
                ", about='" + about + '\'' +
                ", language='" + language + '\'' +
                ", sex=" + sex +
                ", city='" + city + '\'' +
                ", distance='" + distance + '\'' +
                ", interests=" + interests +
                '}';
    }
}
