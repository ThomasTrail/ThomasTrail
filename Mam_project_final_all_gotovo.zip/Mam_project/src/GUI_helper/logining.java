package GUI_helper;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.Objects;

public class logining {
    private boolean islogin = false;
    private Integer id_usr;
    public boolean rtrn_log(){
        return islogin;
    }

    public Integer rtrn_id_usr(){return id_usr;}
    public void check_log(String log, String pwd) throws IOException {
        String url = "api/log?pwd="+URLEncoder.encode(pwd, "UTF-8")+"&log="+URLEncoder.encode(log, "UTF-8");
        String res = ReadFromWeb.readFromWeb(url);  
        System.out.println(res);
        id_usr = Integer.parseInt(res);;
        if (Objects.equals(res, "0")) {
            islogin = false;}
        else{
            islogin = true;
        }
    }

}
