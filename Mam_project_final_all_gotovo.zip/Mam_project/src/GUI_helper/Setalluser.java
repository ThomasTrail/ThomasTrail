package GUI_helper;

import java.io.IOException;
import java.net.URLEncoder;

import org.json.JSONObject;
public class Setalluser {

    public void setUsr(Integer usr_id) throws IOException {
        String url = "usr_return?usrid="+ URLEncoder.encode(Integer.toString(usr_id), "UTF-8");
        System.out.println(url);
        try {
            DBGetter db = new DBGetter();
            String res = ReadFromWeb.readFromWeb(url);
            JSONObject obj = new JSONObject(res);
            conf.usr.setId(obj.getInt("id"));
            conf.usr.setAge(obj.getInt("age"));
            conf.usr.setName(obj.getString("name"));
            conf.usr.setLogin(obj.getString("login"));
            conf.usr.setPassword(obj.getString("password"));
            conf.usr.setHeight(obj.getString("height"));
            conf.usr.setAbout(obj.getString("about"));
            conf.usr.setInterests(db.takeUsrInterest(conf.usr.id));
            conf.usr.setSex(obj.getBoolean("sex"));
            conf.usr.setCity(obj.getString("city"));
            conf.usr.setGoals(obj.getString("goals"));
            url = "ret_lang?id="+ URLEncoder.encode(Integer.toString(conf.usr.id), "UTF-8");
            res = ReadFromWeb.readFromWeb(url);
            conf.usr.setLanguage(res);

            System.out.println(obj.getString("goals"));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
