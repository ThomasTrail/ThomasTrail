package GUI_helper;//http://26.163.76.54:8080/MyServer_war/

public class our_user {
    int id;
    String usr_name;
    String usr_surname;
    boolean sex;
    }
