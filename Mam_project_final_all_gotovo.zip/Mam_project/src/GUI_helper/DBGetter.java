package GUI_helper;

import org.json.JSONArray;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

public class DBGetter {
    private String urlInterests = "api/takeinterests";
    private String urlLanguages = "api/takelanguage";
    private String urlUserInterest = "api/take_user_interest?id=";
    private String urlUsers = "api/takelistusers?id=";
    private List<String> usrInterests=takeInterests();
    private List<String> usrLanguages=takeLanguages();

    public DBGetter() throws IOException {
        
    }

    public List<String> takeInterests() throws IOException {

        String interests =  ReadFromWeb.readFromWeb(urlInterests);
        JSONArray array = new JSONArray(interests);
        usrInterests = array.toList().stream().map(Object::toString).collect(Collectors.toList());
        System.out.println(usrInterests.get(1));
        return usrInterests;
    }
    public List<String> takeLanguages() throws IOException {

        String interests =  ReadFromWeb.readFromWeb(urlLanguages);
        JSONArray array = new JSONArray(interests);
        usrLanguages = array.toList().stream().map(Object::toString).collect(Collectors.toList());
        System.out.println(usrLanguages.get(1));
        return usrLanguages;
    }

    public List<String> takeUsrInterest(Integer id) throws IOException {

        String interests =  ReadFromWeb.readFromWeb(urlUserInterest+Integer.toString(id));
        JSONArray array = new JSONArray(interests);
        List<String> ArInter = array.toList().stream().map(Object::toString).collect(Collectors.toList());
        System.out.println(ArInter);
        return ArInter;
    }

    public List<String> takeUsrs(Integer id) throws IOException {

        String interests =  ReadFromWeb.readFromWeb(urlUsers+Integer.toString(id));
        JSONArray array = new JSONArray(interests);
        List<String> ArInter = array.toList().stream().map(Object::toString).collect(Collectors.toList());
        System.out.println(ArInter);
        return ArInter;
    }

    public List<String> getUsrInterests() {
        return usrInterests;
    }

    public List<String> getUsrLanguages() {
        return usrLanguages;
    }
    //    public static void main(String[] args) throws IOException, InterruptedException {
////        String url = "http://26.157.130.164:8080/takeinterests";
////        String interests =  GUI_helper.ReadFromWeb.readFromWeb("takeinterests");
////        JSONArray array = new JSONArray(interests);
////        List<String> usrInterests = array.toList().stream().map(Object::toString).collect(Collectors.toList());
////        System.out.println(usrInterests.get(1));
//    }
}
