package GUI_helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
//Ratkin
//12
//        shrekus
public class ReadFromWeb {
    public static String readFromWeb(String webURL) throws IOException {
        String start = "http://26.157.130.164:8080/";
        System.out.println(start+webURL);
        URL url = new URL(start+webURL);
        InputStream is =  url.openStream();
        try( BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            String line;
            line = br.readLine();
            System.out.println(line);
            return line;
        }
        catch (MalformedURLException e) {
            e.printStackTrace();
            throw new MalformedURLException("URL is malformed!!");
        }
        catch (IOException e) {
            e.printStackTrace();
            throw new IOException();
        }

    }
}