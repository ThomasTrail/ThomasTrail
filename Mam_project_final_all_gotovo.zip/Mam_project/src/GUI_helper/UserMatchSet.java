package GUI_helper;

import org.json.JSONObject;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class UserMatchSet {
    public UserForMatch u_rtrn(Integer usr_id){
        UserForMatch mu = new UserForMatch();
        System.out.println(usr_id);
        String url = null;
        try {
            url = "usr_return?usrid="+ URLEncoder.encode(Integer.toString(usr_id), "UTF-8");
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        try {
            String res = ReadFromWeb.readFromWeb(url);
            JSONObject obj = new JSONObject(res);
            mu.setId(obj.getInt("id"));
            mu.setAge(obj.getInt("age"));
            mu.setName(obj.getString("name"));
            mu.setHeight(obj.getString("height"));
            mu.setAbout(obj.getString("about"));
            mu.setSex(obj.getBoolean("sex"));
            mu.setCity(obj.getString("city"));
            System.out.println(322322);
            url = "ret_dist?id1="+ URLEncoder.encode(Integer.toString(mu.id), "UTF-8")+"&id2="+ URLEncoder.encode(Integer.toString(conf.usr.id), "UTF-8");

            res = ReadFromWeb.readFromWeb(url);
            mu.setDistance(res);
            DBGetter db = new DBGetter();
            mu.setInterests(db.takeUsrInterest(mu.id));
            mu.setLanguage("РУССКИЙ");
        } catch (IOException e) {
            System.out.println(322322);
            throw new RuntimeException(e);
        }
        return mu;
    }
}