package GUI_helper;

import java.util.List;

public class UserForMatch {

    public String name;
    public Integer id;



    public Integer age;
    public String height;
    public String about;
    public String language;
    public Boolean sex;
    public String city;
    public String distance;
    public List<String> interests;

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public void setAbout(String about) {
        this.about = about;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public void setSex(Boolean sex) {
        this.sex = sex;
    }

    @Override
    public String toString() {
        return "MatchUser{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", age=" + age +
                ", height='" + height + '\'' +
                ", about='" + about + '\'' +
                ", language='" + language + '\'' +
                ", sex=" + sex +
                ", city='" + city + '\'' +
                ", distance='" + distance + '\'' +
                ", interests=" + interests +
                '}';
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public void setInterests(List<String> interests) {
        this.interests = interests;
    }
}