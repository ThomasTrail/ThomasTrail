package GUI_main;

import GUI_helper.*;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class wind extends JFrame {
    private JPanel contentPane;
    private JButton xButton;
    private JButton button2;
    private JButton button3;
    private JButton button4;
    private JButton button5;
    private JLabel lbName;
    private JLabel lbAge;
    private JLabel lbCity;
    private JLabel lbDist;
    private JLabel lbInterests;
    private JLabel lbAbout;
    private JLabel lbLang;
    private JPanel photo;
    private JPanel bckgnd;
    private JLabel my_label;
    private JButton btnmatches;
    private JButton btnsettings;
    private JButton btnExit;
    private int counter = 0, iteration = 1;
    private ImageIcon scaleImage = null;
    private JButton buttonOK;
    private Integer iter =0;
    private ArrayList<String> src_photo;
    private boolean likeflag;
    private UserMatchSet usr = new UserMatchSet();
    private UserForMatch end_usr = new UserForMatch();

    private Image image = null;/* w  ww .  ja  v  a 2 s.c o m*/


    public wind() throws IOException {
        DBGetter ids = new DBGetter();
        List<String> usr_ids = ids.takeUsrs(conf.usr.id);
        conf.usr.setAllUsers(usr_ids);
        System.out.println();
        System.out.println(usr_ids);
        System.out.println();
        end_usr = usr.u_rtrn(Integer.parseInt(usr_ids.get(iter)));


        setContentPane(contentPane);
        setVisible(false);
        getRootPane().setDefaultButton(buttonOK);
        try {

            //String urrr= "http://26.157.130.164:8080/download?iu="+GUI_helper.conf.usr.id;
            URL url = new URL("http://26.157.130.164:8080/download?iu=" + conf.usr.allUsers.get(iter));
            //loginpage.src_photo.get(counter++)
            image = ImageIO.read(url);
            scaleImage = new ImageIcon(new ImageIcon(image).getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            my_label.setIcon(scaleImage);
        }
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                likeflag = false;
                try {
                    on_next();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
                String url = "fillmatch?id1="+Integer.toString(conf.usr.id)+"&id2="+Integer.toString(end_usr.id);
                try{
                String res = ReadFromWeb.readFromWeb(url);}
                catch (Exception f){}
            }
        });
        xButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    on_next();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
//        btnmatches.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//
//            }
//        });
        btnsettings.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                on_settings();
            }
        });
        button5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                lbName.setText(end_usr.name);
                lbCity.setText(end_usr.city);
                lbAbout.setText(end_usr.about);
                lbAge.setText(Integer.toString(end_usr.age));
                lbDist.setText(end_usr.distance);
                lbInterests.setText(end_usr.interests.toString());
                lbLang.setText(end_usr.language);
            }
        });
        btnExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

    }

    public void on_settings() {

        this.setVisible(false);
        stngs sth_wd = new stngs();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        sth_wd.setSize(800, 900);
        int x = (screenSize.width - sth_wd.getWidth()) / 2;
        int y = (screenSize.height - sth_wd.getHeight()) / 2;
        sth_wd.setLocation(x, y);
        sth_wd.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        sth_wd.setVisible(true);
    }

    public void on_next() throws IOException {
        if(iter+1<conf.usr.allUsers.size()){
            lbName.setText("");
            lbCity.setText("");
            lbAbout.setText("");
            lbAge.setText("");
            lbDist.setText("");
            lbInterests.setText("");
            lbLang.setText("");
            iter++;}
            end_usr = usr.u_rtrn(Integer.parseInt(conf.usr.allUsers.get(iter)));
            try {

                //String urrr= "http://26.157.130.164:8080/download?iu="+GUI_helper.conf.usr.id;
                URL url = new URL("http://26.157.130.164:8080/download?iu=" + conf.usr.allUsers.get(iter));
                //loginpage.src_photo.get(counter++)
                image = ImageIO.read(url);
                scaleImage = new ImageIcon(new ImageIcon(image).getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT));
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                my_label.setIcon(scaleImage);
            }
            //src_photo = "/2.jpg"

    }


    public static void main(String[] args) throws IOException {
        main_mam dialog = new main_mam();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        contentPane = new JPanel();
        contentPane.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(4, 2, new Insets(10, 10, 10, 10), -1, -1));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(panel1, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, 1, null, null, null, 0, false));
        button5 = new JButton();
        button5.setText("...");
        panel1.add(button5, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        button2 = new JButton();
        button2.setBackground(new Color(-15540736));
        button2.setForeground(new Color(-16777216));
        button2.setText("♥");
        panel1.add(button2, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        photo = new JPanel();
        photo.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(8, 2, new Insets(0, 0, 0, 0), -1, -1));
        photo.putClientProperty("html.disable", Boolean.FALSE);
        contentPane.add(photo, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 1, false));
        bckgnd = new JPanel();
        bckgnd.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        photo.add(bckgnd, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 8, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        my_label = new JLabel();
        my_label.setAutoscrolls(false);
        my_label.setDoubleBuffered(false);
        my_label.setIcon(new ImageIcon(getClass().getResource("/GUI_main/clinkz.png")));
        my_label.setText("");
        my_label.setVisible(true);
        bckgnd.add(my_label, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, new Dimension(400, 400), new Dimension(400, 400), 0, false));
        lbName = new JLabel();
        lbName.setText("");
        photo.add(lbName, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbAge = new JLabel();
        lbAge.setText("");
        photo.add(lbAge, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbCity = new JLabel();
        lbCity.setText("");
        photo.add(lbCity, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbDist = new JLabel();
        lbDist.setText("");
        photo.add(lbDist, new com.intellij.uiDesigner.core.GridConstraints(3, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbInterests = new JLabel();
        lbInterests.setText("");
        photo.add(lbInterests, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbAbout = new JLabel();
        lbAbout.setText("");
        photo.add(lbAbout, new com.intellij.uiDesigner.core.GridConstraints(5, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbLang = new JLabel();
        lbLang.setText("");
        photo.add(lbLang, new com.intellij.uiDesigner.core.GridConstraints(6, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        photo.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(7, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        btnsettings = new JButton();
        btnsettings.setText("Настройки");
        contentPane.add(btnsettings, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnmatches = new JButton();
        btnmatches.setText("Совпадения");
        contentPane.add(btnmatches, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        xButton = new JButton();
        xButton.setBackground(new Color(-390400));
        xButton.setForeground(new Color(-16777216));
        xButton.setText("x");
        contentPane.add(xButton, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnExit = new JButton();
        btnExit.setText("Выйти");
        contentPane.add(btnExit, new com.intellij.uiDesigner.core.GridConstraints(3, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return contentPane;
    }

}
