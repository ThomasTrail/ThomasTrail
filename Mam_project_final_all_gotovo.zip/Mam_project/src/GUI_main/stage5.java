package GUI_main;

import GUI_helper.ReadFromWeb;
import GUI_helper.User;
import GUI_helper.conf;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Locale;

public class stage5 extends JPanel {
    private registerpage rp;
    private JPanel stage5;
    private JPanel regtxt;
    private JLabel lbreg;
    private JPanel btns;
    private JButton btnEnd;
    private JButton btnBack;
    private JPanel logtxt;
    private JButton btnPic;
    private JLabel lbPic;
    public JFileChooser fileChooser = new JFileChooser();
    private File a;
    public User user = new User();

    public stage5() {
        setVisible(false);
        setEnabled(false);
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rp.back5to4();
            }
        });
        btnEnd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //
            }
        });
        btnPic.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    chng();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        btnEnd.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    registerUser();
                    String url = "api/change_int?int1=" + URLEncoder.encode(user.interests.get(0), "UTF-8") + "&int2="
                            + URLEncoder.encode(user.interests.get(1), "UTF-8") + "&int3=" + URLEncoder.encode(user.interests.get(2), "UTF-8") +
                            "&int4=" + URLEncoder.encode(user.interests.get(3), "UTF-8") + "&int5=" + URLEncoder.encode(user.interests.get(4), "UTF-8");
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

                MultipartEntityBuilder builder = MultipartEntityBuilder.create();
                builder.addBinaryBody("file", a, ContentType.DEFAULT_BINARY, conf.usr.getId().toString() + ".jpg");
                String url = "http://26.157.130.164:8080/api/upload";
                HttpEntity entity = builder.build();

                HttpPost httpPost = new HttpPost(url);
                httpPost.setEntity(entity);

                HttpClient httpClient = HttpClients.createDefault();
                HttpResponse response = null;
                try {
                    response = httpClient.execute(httpPost);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }

                System.out.println("Response code: " + response.getStatusLine().getStatusCode());
                System.out.println("Response message: " + response.getStatusLine().getReasonPhrase());
            }
        });
    }

    public void chng() throws IOException {
        int ret = fileChooser.showOpenDialog(this);
        if (ret != JFileChooser.APPROVE_OPTION) return;
        lbPic.setHorizontalAlignment(SwingConstants.CENTER);
        a = fileChooser.getSelectedFile();
        String Path = a.getAbsolutePath();//path to pic
        System.out.println(Path);
        ImageIcon scaleImage = new ImageIcon(new ImageIcon(Path).getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT));
        lbPic.setIcon(scaleImage);

    }

    private void registerUser() throws IOException {
        String name = rp.stage2.getName();
        String login = rp.getLog();
        String age = rp.stage2.getAge();
        String password = rp.getPassw();
        String confirmPassword = rp.getPassw2();
        String height = rp.stage3.getheight();
        String about = rp.stage3.getAbout();
        Boolean sex = rp.stage2.getSex();
        String city = rp.stage3.getCity();
        String goals = " ";
        String goal1 = rp.stage4.getGoal1();
        String goal2 = rp.stage4.getGoal2();
        String goal3 = rp.stage4.getGoal3();
        String goal4 = rp.stage4.getGoal4();
        String goal5 = rp.stage4.getGoal5();

        if (name.isEmpty() || about.isEmpty() || login.isEmpty() || age.isEmpty() || password.isEmpty() || height.isEmpty() || city.isEmpty() || goals.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter all fields",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }


        int if_log = addUserToDatabase(name, age, login, password, height, about, sex, city, goals);
        System.out.println(if_log);
        if (if_log != 0) {

            user.name = name;
            user.age = Integer.parseInt(age);
            user.login = login;
            user.password = password;
            user.height = height;
            user.about = about;
            user.sex = sex;
            user.city = city;
            user.goals = " ";
            user.interests.add(goal1);
            user.interests.add(goal2);
            user.interests.add(goal3);
            user.interests.add(goal4);
            user.interests.add(goal5);
            //dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Failed to register new user",
                    "Try again",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private int addUserToDatabase(String name, String age, String login, String password, String height, String about, Boolean sex, String city, String goals) throws IOException {

        String url = "api/reg?name=" + URLEncoder.encode(name, "UTF-8") + "&age=" + URLEncoder.encode(age, "UTF-8") + "&log=" + URLEncoder.encode(login, "UTF-8") + "&pwd=" + URLEncoder.encode(password, "UTF-8") + "&hg=" + URLEncoder.encode(height, "UTF-8") + "&ab=" + URLEncoder.encode(about, "UTF-8") + "&sex=" + sex + "&ct=" + URLEncoder.encode(city, "UTF-8") + "&gl=" + URLEncoder.encode(goals, "UTF-8") + "";
        String res = ReadFromWeb.readFromWeb(url);
        System.out.println(res);
        return Integer.parseInt(res);
    }

    public void setRp(registerpage th) {
        rp = th;
    }

    public JPanel getStage5() {
        return stage5;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        stage5 = new JPanel();
        stage5.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(3, 1, new Insets(0, 0, 0, 0), -1, -1));
        stage5.setBackground(new Color(-1));
        stage5.setForeground(new Color(-1));
        regtxt = new JPanel();
        regtxt.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        regtxt.setBackground(new Color(-1));
        regtxt.setForeground(new Color(-1));
        stage5.add(regtxt, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        lbreg = new JLabel();
        Font lbregFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 36, lbreg.getFont());
        if (lbregFont != null) lbreg.setFont(lbregFont);
        lbreg.setText("Регистрация");
        regtxt.add(lbreg, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btns = new JPanel();
        btns.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 4, new Insets(0, 0, 0, 0), -1, -1));
        btns.setBackground(new Color(-1));
        stage5.add(btns, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        btnEnd = new JButton();
        btnEnd.setActionCommand("Конец");
        btnEnd.setBackground(new Color(-16777216));
        Font btnEndFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 14, btnEnd.getFont());
        if (btnEndFont != null) btnEnd.setFont(btnEndFont);
        btnEnd.setForeground(new Color(-1));
        btnEnd.setText("Конец");
        btns.add(btnEnd, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnBack = new JButton();
        btnBack.setBackground(new Color(-16777216));
        Font btnBackFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 14, btnBack.getFont());
        if (btnBackFont != null) btnBack.setFont(btnBackFont);
        btnBack.setForeground(new Color(-1));
        btnBack.setText("Назад");
        btns.add(btnBack, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(0, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer2 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer2, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer3 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer3, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        logtxt = new JPanel();
        logtxt.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 1, new Insets(0, 0, 0, 0), -1, -1));
        logtxt.setBackground(new Color(-1));
        logtxt.setEnabled(true);
        stage5.add(logtxt, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        lbPic = new JLabel();
        lbPic.setIcon(new ImageIcon(getClass().getResource("/GUI_main/Usrphoto.png")));
        lbPic.setText("");
        logtxt.add(lbPic, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(625, 625), null, 0, false));
        btnPic = new JButton();
        btnPic.setAutoscrolls(false);
        btnPic.setBackground(new Color(-16777216));
        Font btnPicFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 14, btnPic.getFont());
        if (btnPicFont != null) btnPic.setFont(btnPicFont);
        btnPic.setForeground(new Color(-1));
        btnPic.setText("Выбор Фото");
        logtxt.add(btnPic, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return stage5;
    }

}
