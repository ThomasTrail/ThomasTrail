package GUI_main;

import GUI_helper.DBGetter;
import GUI_helper.ReadFromWeb;
import GUI_helper.Setalluser;
import GUI_helper.conf;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.HttpClients;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.RoundRectangle2D;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;

import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.border.AbstractBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
/*
 * ПОСМОТРИ ПОЖАЛУЙСТА СТРОЧКУ 115 и надо решить как будем сохранять
 * btnSavExit --> пачкой или
 * в каждом отдельном полe(затычки ниже)
 * Чтоб не делать лишней хуйни
 * */

public class stngs extends JFrame {

    private JLabel Lifestyle;
    private JButton changePhotoButton;
    private JButton btnChAge;
    private JButton btnChAbout;
    private JButton btnChName;
    private JPanel Pudj;
    private JLabel lbPicture;
    private JComboBox cbLang;
    private JTextField tfAbout;
    private JTextField tfName;
    private JLabel lbLabel;
    private JLabel fnLang;
    private JLabel lbName;
    private JLabel lbAbout;
    private JTextField tfMaintags;
    private JComboBox cbAge;
    private JButton btnSavExit;
    private JButton btnLogout;
    private JComboBox cbInterests1;
    private JComboBox cbInterests2;
    private JComboBox cbInterests3;
    private JComboBox cbInterests5;
    private JComboBox cbInterests4;
    private JTextField tfCity;
    private JButton btnChCity;
    private JLabel label;
    private Image image = null;
    public JFileChooser fileChooser = new JFileChooser();
    private String age;
    private Setalluser refresh = new Setalluser();


    public stngs() {
        //super(parent.getGraphicsConfiguration());
        System.out.println(1232341243);
        setContentPane(Pudj);
        setVisible(false);
        lbPicture.setBorder(new RoundedBorder(Color.cyan, 20));
        setDefaultCloseOperation(2);


        changePhotoButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    chng();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        btnChName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btnChName.getText() == "Change") {
                    btnChName.setText("Save");
                    tfName.setEnabled(true);
                    String url=null;
                    try {
                        url = "change_name?id="+Integer.toString(conf.usr.id)+"&name="+URLEncoder.encode(tfName.getText(),"UTF-8");
                    } catch (UnsupportedEncodingException ex) {
                        throw new RuntimeException(ex);
                    }
                    try {
                        String res = ReadFromWeb.readFromWeb(url);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    btnChName.setText("Change");
                    tfName.setEnabled(false);
                    //насрать сохранение изменения в серв
                }
            }
        });
        btnChAge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btnChAge.getText() == "Изменить") {
                    btnChAge.setText("Сохранить");
                    cbAge.setEnabled(true);
//                    String url=null;
//                    try {
//                        url = "change_name?id=&name="+URLEncoder.encode(tfName.getText(),"UTF-8");
//                    } catch (UnsupportedEncodingException ex) {
//                        throw new RuntimeException(ex);
//                    }
//                    try {
//                        String res = GUI_helper.ReadFromWeb.readFromWeb(url);
//                    } catch (IOException ex) {
//                        throw new RuntimeException(ex);
//                    }
                } else {
                    btnChAge.setText("Изменить");
                    cbAge.setEnabled(false);
                    age = cbAge.getSelectedItem().toString();
                    //насрать сохранение изменения в серв
                }
            }
        });
        btnSavExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    savexit();
                } catch (UnsupportedEncodingException ex) {
                    throw new RuntimeException(ex);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }

            public void savexit() throws IOException {
                DBGetter ids = new DBGetter();
                String url = "change_int?int1=" + URLEncoder.encode(cbInterests1.getSelectedItem().toString(),"UTF-8")+"&int2="+
                        URLEncoder.encode(cbInterests2.getSelectedItem().toString(),"UTF-8")+"&int3="+
                        URLEncoder.encode(cbInterests3.getSelectedItem().toString(),"UTF-8")+"&int4="+
                        URLEncoder.encode(cbInterests4.getSelectedItem().toString(),"UTF-8")+"&int5="+
                        URLEncoder.encode(cbInterests5.getSelectedItem().toString(),"UTF-8")+
                        "&id="+Integer.toString(conf.usr.id);
                String req = ReadFromWeb.readFromWeb(url);
                System.out.println(conf.usr.id);
                refresh.setUsr(conf.usr.id);
                try{
                   conf.usr.setAllUsers(ids.takeUsrs(conf.usr.id));}
                catch (Exception e) {
                    throw new RuntimeException(e);
                }
                dispose();
                loginpage1.getMain_wd_vision();
            }
        });
        btnChAbout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btnChAbout.getText() == "Изменить") {
                    btnChAbout.setText("Сохранить");
                    tfAbout.setEnabled(true);
                    String url = null;
                    try {
                        url = "change_about?id="+Integer.toString(conf.usr.id)+"&about="+URLEncoder.encode(tfAbout.getText(),"UTF-8");
                    } catch (UnsupportedEncodingException ex) {
                        throw new RuntimeException(ex);
                    }
                    try {
                        String res = ReadFromWeb.readFromWeb(url);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    btnChAbout.setText("Изменить");
                    tfAbout.setEnabled(false);
                    //насрать сохранение изменения в серв
                }
            }
        });
        btnChCity.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (btnChCity.getText() == "Изменить") {
                    btnChCity.setText("Сохранить");
                    tfCity.setEnabled(true);
                    String url = null;
                    try {
                        url = "change_city?id="+Integer.toString(conf.usr.id)+"&city="+ URLEncoder.encode(tfCity.getText(),"UTF-8");
                    } catch (UnsupportedEncodingException ex) {
                        throw new RuntimeException(ex);
                    }
                    try {
                        String res = ReadFromWeb.readFromWeb(url);
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                } else {
                    btnChCity.setText("Изменить");
                    tfCity.setEnabled(false);
                    //насрать сохранение изменения в серв
                }
            }
        });


    }

    public void chng() throws IOException {
        int ret = fileChooser.showOpenDialog(this);
        if (ret != JFileChooser.APPROVE_OPTION) return;
        lbPicture.setHorizontalAlignment(SwingConstants.CENTER);
        File a = fileChooser.getSelectedFile();
        String Path = a.getAbsolutePath();//path to pic
        System.out.println(Path);
        ImageIcon scaleImage = new ImageIcon(new ImageIcon(Path).getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT));
        lbPicture.setIcon(scaleImage);
        MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        builder.addBinaryBody("file", a, ContentType.DEFAULT_BINARY, conf.usr.getId().toString() + ".jpg");
        String url = "http://26.157.130.164:8080/upload";
        HttpEntity entity = builder.build();

        HttpPost httpPost = new HttpPost(url);
        httpPost.setEntity(entity);

        HttpClient httpClient = HttpClients.createDefault();
        HttpResponse response = httpClient.execute(httpPost);

        System.out.println("Response code: " + response.getStatusLine().getStatusCode());
        System.out.println("Response message: " + response.getStatusLine().getReasonPhrase());
    }

    public static void main(String[] args) {
        Settings settings = new Settings();
        settings.pack();
        settings.setVisible(false);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!

            $$$setupUI$$$();

    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        DBGetter interests = null;
        try {
            interests = new DBGetter();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        Pudj = new JPanel();
        Pudj.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(14, 5, new Insets(0, 0, 0, 0), -1, -1));
        Pudj.setBackground(new Color(-4473925));
        lbName = new JLabel();
        lbName.setBackground(new Color(-15711995));
        Font lbNameFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, lbName.getFont());
        if (lbNameFont != null) lbName.setFont(lbNameFont);
        lbName.setIcon(new ImageIcon(getClass().getResource("/GUI_main/age.png")));
        lbName.setText("");
        Pudj.add(lbName, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(126, 32), null, 0, false));
        lbAbout = new JLabel();
        Font lbAboutFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 18, lbAbout.getFont());
        if (lbAboutFont != null) lbAbout.setFont(lbAboutFont);
        lbAbout.setForeground(new Color(-16777216));
        lbAbout.setText("О себе");
        Pudj.add(lbAbout, new com.intellij.uiDesigner.core.GridConstraints(6, 0, 1, 5, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Lifestyle = new JLabel();
        Font LifestyleFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 18, Lifestyle.getFont());
        if (LifestyleFont != null) Lifestyle.setFont(LifestyleFont);
        Lifestyle.setForeground(new Color(-16777216));
        Lifestyle.setText("Интересы");
        Pudj.add(Lifestyle, new com.intellij.uiDesigner.core.GridConstraints(12, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfAbout = new JTextField();
        tfAbout.setBackground(new Color(-65538));
        tfAbout.setDisabledTextColor(new Color(-16777216));
        tfAbout.setEditable(true);
        tfAbout.setEnabled(false);
        Font tfAboutFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, tfAbout.getFont());
        if (tfAboutFont != null) tfAbout.setFont(tfAboutFont);
        tfAbout.setForeground(new Color(-16373912));
        tfAbout.setText(conf.usr.about);
        Pudj.add(tfAbout, new com.intellij.uiDesigner.core.GridConstraints(7, 0, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfName = new JTextField();
        tfName.setBackground(new Color(-65538));
        tfName.setDisabledTextColor(new Color(-16777216));
        tfName.setEnabled(false);
        Font tfNameFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, tfName.getFont());
        if (tfNameFont != null) tfName.setFont(tfNameFont);
        tfName.setText(conf.usr.name);
        Pudj.add(tfName, new com.intellij.uiDesigner.core.GridConstraints(11, 0, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        lbLabel = new JLabel();
        Font lbLabelFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 18, lbLabel.getFont());
        if (lbLabelFont != null) lbLabel.setFont(lbLabelFont);
        lbLabel.setForeground(new Color(-16777216));
        lbLabel.setText("Персональные настройки");
        Pudj.add(lbLabel, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 5, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        lbPicture = new JLabel();
        try {
            String urrr= "http://26.157.130.164:8080/download?iu="+conf.usr.id;
            URL url = new URL(urrr);
            //loginpage.src_photo.get(counter++)
            image = ImageIO.read(url);
            ImageIcon scaleImage = new ImageIcon(new ImageIcon(image).getImage().getScaledInstance(400, 400, Image.SCALE_DEFAULT));
            lbPicture.setIcon(scaleImage);
        }catch (IOException e){lbPicture.setIcon(new ImageIcon(getClass().getResource("/GUI_main/Usrphoto.png")));}
        lbPicture.setText("");
        Pudj.add(lbPicture, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 2, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(402, 254), null, 0, false));
        changePhotoButton = new JButton();
        changePhotoButton.setBackground(new Color(-8750718));
        Font changePhotoButtonFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, -1, changePhotoButton.getFont());
        if (changePhotoButtonFont != null) changePhotoButton.setFont(changePhotoButtonFont);
        changePhotoButton.setForeground(new Color(-1));
        changePhotoButton.setText("Загрузите фото");
        Pudj.add(changePhotoButton, new com.intellij.uiDesigner.core.GridConstraints(2, 2, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        cbLang = new JComboBox();
        cbLang.setBackground(new Color(-8750718));
        Font cbLangFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbLang.getFont());
        if (cbLangFont != null) cbLang.setFont(cbLangFont);
        cbLang.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel1 = new DefaultComboBoxModel();
        defaultComboBoxModel1.addElement(conf.usr.language);
        for(String str: interests.getUsrLanguages() )
        {defaultComboBoxModel1.addElement(str);}
        cbLang.setModel(defaultComboBoxModel1);
        Pudj.add(cbLang, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        fnLang = new JLabel();
        Font fnLangFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 18, fnLang.getFont());
        if (fnLangFont != null) fnLang.setFont(fnLangFont);
        fnLang.setForeground(new Color(-16777216));
        fnLang.setText("Язык");
        Pudj.add(fnLang, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(126, 25), null, 0, false));
        btnChAbout = new JButton();
        btnChAbout.setBackground(new Color(-8750718));
        Font btnChAboutFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, -1, btnChAbout.getFont());
        if (btnChAboutFont != null) btnChAbout.setFont(btnChAboutFont);
        btnChAbout.setForeground(new Color(-1));
        btnChAbout.setText("Изменить");
        Pudj.add(btnChAbout, new com.intellij.uiDesigner.core.GridConstraints(7, 3, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnChName = new JButton();
        btnChName.setBackground(new Color(-8750718));
        Font btnChNameFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, -1, btnChName.getFont());
        if (btnChNameFont != null) btnChName.setFont(btnChNameFont);
        btnChName.setForeground(new Color(-1));
        btnChName.setText("Изменить");
        Pudj.add(btnChName, new com.intellij.uiDesigner.core.GridConstraints(11, 3, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        cbAge = new JComboBox();
        cbAge.setBackground(new Color(-8750718));
        cbAge.setEditable(false);
        cbAge.setEnabled(false);
        Font cbAgeFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbAge.getFont());
        if (cbAgeFont != null) cbAge.setFont(cbAgeFont);
        cbAge.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel2 = new DefaultComboBoxModel();
        defaultComboBoxModel2.addElement(conf.usr.age);
        defaultComboBoxModel2.addElement("18");
        defaultComboBoxModel2.addElement("19");
        defaultComboBoxModel2.addElement("20");
        defaultComboBoxModel2.addElement("21");
        defaultComboBoxModel2.addElement("22");
        defaultComboBoxModel2.addElement("23");
        defaultComboBoxModel2.addElement("24");
        defaultComboBoxModel2.addElement("25");
        defaultComboBoxModel2.addElement("26");
        defaultComboBoxModel2.addElement("27");
        defaultComboBoxModel2.addElement("28");
        defaultComboBoxModel2.addElement("29");
        defaultComboBoxModel2.addElement("30");
        defaultComboBoxModel2.addElement("31");
        defaultComboBoxModel2.addElement("32");
        defaultComboBoxModel2.addElement("33");
        defaultComboBoxModel2.addElement("34");
        cbAge.setModel(defaultComboBoxModel2);
        Pudj.add(cbAge, new com.intellij.uiDesigner.core.GridConstraints(5, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnChAge = new JButton();
        btnChAge.setBackground(new Color(-8750718));
        Font btnChAgeFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, -1, btnChAge.getFont());
        if (btnChAgeFont != null) btnChAge.setFont(btnChAgeFont);
        btnChAge.setForeground(new Color(-3156274));
        btnChAge.setHideActionText(true);
        btnChAge.setText("Изменить");
        Pudj.add(btnChAge, new com.intellij.uiDesigner.core.GridConstraints(5, 3, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 16, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setForeground(new Color(-16777216));
        label1.setText("Ваш Город");
        Pudj.add(label1, new com.intellij.uiDesigner.core.GridConstraints(8, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(126, 22), null, 0, false));
        btnLogout = new JButton();
        btnLogout.setText("Выйти из профиля");
        Pudj.add(btnLogout, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnSavExit = new JButton();
        btnSavExit.setBackground(new Color(-8750718));
        Font btnSavExitFont = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 26, btnSavExit.getFont());
        if (btnSavExitFont != null) btnSavExit.setFont(btnSavExitFont);
        btnSavExit.setForeground(new Color(-1));
        btnSavExit.setHideActionText(false);
        btnSavExit.setText("Сохранить и вернуться");
        Pudj.add(btnSavExit, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 1, false));
        cbInterests1 = new JComboBox();
        Pudj.add(cbInterests1, new com.intellij.uiDesigner.core.GridConstraints(13, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Font cbInterests1Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbInterests1.getFont());
        if (cbInterests1Font != null) cbInterests1.setFont(cbAgeFont);
        cbInterests1.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel8 = new DefaultComboBoxModel();
        defaultComboBoxModel8.addElement(conf.usr.interests.get(0));
        for(String str: interests.getUsrInterests()){
            defaultComboBoxModel8.addElement(str);}
        cbInterests1.setModel(defaultComboBoxModel8);
        cbInterests2 = new JComboBox();
        Pudj.add(cbInterests2, new com.intellij.uiDesigner.core.GridConstraints(13, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Font cbInterests2Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbInterests1.getFont());
        if (cbInterests1Font != null) cbInterests2.setFont(cbAgeFont);
        cbInterests2.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel3 = new DefaultComboBoxModel();
        defaultComboBoxModel3.addElement(conf.usr.interests.get(1));
        for(String str: interests.getUsrInterests()){
            defaultComboBoxModel3.addElement(str);}
        cbInterests2.setModel(defaultComboBoxModel3);
        cbInterests3 = new JComboBox();
        Pudj.add(cbInterests3, new com.intellij.uiDesigner.core.GridConstraints(13, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Font cbInterests3Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbInterests1.getFont());
        if (cbInterests1Font != null) cbInterests3.setFont(cbAgeFont);
        cbInterests3.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel4 = new DefaultComboBoxModel();
        defaultComboBoxModel4.addElement(conf.usr.interests.get(2));
        for(String str: interests.getUsrInterests()){
            defaultComboBoxModel4.addElement(str);}
        cbInterests3.setModel(defaultComboBoxModel4);
        cbInterests5 = new JComboBox();
        cbInterests5.setEditable(false);
        Pudj.add(cbInterests5, new com.intellij.uiDesigner.core.GridConstraints(13, 4, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Font cbInterests4Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbInterests1.getFont());
        if (cbInterests1Font != null) cbInterests5.setFont(cbAgeFont);
        cbInterests5.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel5 = new DefaultComboBoxModel();
        defaultComboBoxModel5.addElement(conf.usr.interests.get(4));
        for(String str: interests.getUsrInterests()){
            defaultComboBoxModel5.addElement(str);}
        cbInterests5.setModel(defaultComboBoxModel5);
        cbInterests4 = new JComboBox();
        Pudj.add(cbInterests4, new com.intellij.uiDesigner.core.GridConstraints(13, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        Font cbInterests6Font = this.$$$getFont$$$("JetBrains Mono", Font.ITALIC, 12, cbInterests1.getFont());
        if (cbInterests1Font != null) cbInterests4.setFont(cbAgeFont);
        cbInterests4.setForeground(new Color(-16777216));
        final DefaultComboBoxModel defaultComboBoxModel6 = new DefaultComboBoxModel();
        defaultComboBoxModel6.addElement(conf.usr.interests.get(3));
        for(String str: interests.getUsrInterests()){
            defaultComboBoxModel6.addElement(str);}
        cbInterests4.setModel(defaultComboBoxModel6);
        final JLabel label2 = new JLabel();
        label2.setForeground(new Color(-16777216));
        label2.setText("Ваше имя");
        Pudj.add(label2, new com.intellij.uiDesigner.core.GridConstraints(10, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfCity = new JTextField();
        tfCity.setEnabled(false);
        tfCity.setText(conf.usr.city);
        Pudj.add(tfCity, new com.intellij.uiDesigner.core.GridConstraints(9, 0, 1, 3, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        btnChCity = new JButton();
        btnChCity.setEnabled(true);
        btnChCity.setText("Изменить");
        Pudj.add(btnChCity, new com.intellij.uiDesigner.core.GridConstraints(9, 3, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return Pudj;
    }


    private class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int gap;

        public RoundedBorder(Color c, int g) {
            color = c;
            gap = g;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setColor(color);
            g2d.draw(new RoundRectangle2D.Double(x, y, width - 1, height - 1, gap, gap));
            g2d.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return (getBorderInsets(c, new Insets(gap, gap, gap, gap)));
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = insets.top = insets.right = insets.bottom = gap / 2;
            return insets;
        }

        @Override
        public boolean isBorderOpaque() {
            return false;
        }
    }

}
