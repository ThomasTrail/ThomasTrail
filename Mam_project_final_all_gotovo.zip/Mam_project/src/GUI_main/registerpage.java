package GUI_main;

import GUI_helper.DBGetter;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Locale;

public class registerpage extends JFrame {
    private JPanel mainReg;
    private JButton btnNext;
    private JButton btnBack;
    private JPasswordField tfPassConfirm;
    private JPasswordField tfPassEnter;
    private JTextField tfLogin;

    public JPanel submainReg;

    private JPanel stage1;
    private JPanel regtxt;
    private JLabel lbreg;
    private JPanel btns;
    private JPanel logtxt;
    private JLabel login;
    private JLabel pass;
    private JLabel confirmpass;
    private String log = "", passw = "", passw2 = "";
    public stage2 stage2;
    public stage3 stage3;
    public stage4 stage4;
    public stage5 stage5;
    private DBGetter interest;





    public DBGetter getInterest() {
        return interest;
    }

    public GUI_main.stage3 getStage3() {
        return stage3;
    }

    public GUI_main.stage4 getStage4() {
        return stage4;
    }

    public GUI_main.stage5 getStage5() {
        return stage5;
    }

    public String getLog() {
        return log;
    }

    public String getPassw() {
        return passw;
    }

    public String getPassw2() {
        return passw2;
    }

    public void back2to1() {
        stage2.getStage2().setVisible(false);
        stage2.getStage2().setEnabled(false);
        stage1.setEnabled(true);
        stage1.setVisible(true);
    }

    public void back3to2() {
        stage3.getStage3().setVisible(false);
        stage3.getStage3().setEnabled(false);
        stage2.getStage2().setEnabled(true);
        stage2.getStage2().setVisible(true);
    }

    public void back4to3() {
        stage4.getStage4().setVisible(false);
        stage4.getStage4().setEnabled(false);
        stage3.getStage3().setEnabled(true);
        stage3.getStage3().setVisible(true);
    }

    public void back5to4() {
        stage5.getStage5().setVisible(false);
        stage5.getStage5().setEnabled(false);
        stage4.getStage4().setEnabled(true);
        stage4.getStage4().setVisible(true);
    }

    public void Stage2to3() {
        stage2.getStage2().setVisible(false);
        stage2.getStage2().setEnabled(false);
        stage3.getStage3().setEnabled(true);
        stage3.getStage3().setVisible(true);
    }

    public void Stage3to4() {
        stage3.getStage3().setVisible(false);
        stage3.getStage3().setEnabled(false);
        stage4.getStage4().setEnabled(true);
        stage4.getStage4().setVisible(true);
    }

    public void Stage4to5() {
        stage4.getStage4().setVisible(false);
        stage4.getStage4().setEnabled(false);
        stage5.getStage5().setEnabled(true);
        stage5.getStage5().setVisible(true);
    }


    public registerpage() {
        setContentPane(mainReg);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        try {
            interest = new DBGetter();
            System.out.println(interest.getUsrInterests());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        stage2 = new stage2();
        stage2.setRp(this);
        stage3 = new stage3();
        stage3.setRp(this);
        stage4 = new stage4();
        stage4.setRp(this);
        stage4.setCBoxes();
        stage5 = new stage5();
        stage5.setRp(this);


        submainReg.add(stage2.getStage2(), new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        submainReg.add(stage3.getStage3(), new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        submainReg.add(stage4.getStage4(), new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        submainReg.add(stage5.getStage5(), new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));

        btnNext.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                log = tfLogin.getText();
                passw = tfPassEnter.getText();
                passw2 = tfPassConfirm.getText();
                if (!passw.equals(passw2)) {
                    JOptionPane.showMessageDialog(submainReg,
                            "Confirm Password does not match",
                            "Try again",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //System.out.println(log + " " + passw + " " + passw2);
                stage1.setVisible(false);
                stage1.setEnabled(false);
                stage2.getStage2().setEnabled(true);
                stage2.getStage2().setVisible(true);
            }
        });
        btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                loginpage lg = new loginpage();
                lg.setVisible(true);
                //lg.setLocation();
                //lg.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            }
        });

    }

    public static void main(String args[]) {
        registerpage kiki = new registerpage();
        kiki.pack();
        //kiki.setVisible(true);
        kiki.setSize(700, 900);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        mainReg = new JPanel();
        mainReg.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 3, new Insets(0, 0, 0, 0), -1, -1));
        mainReg.setBackground(new Color(-1));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        mainReg.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer2 = new com.intellij.uiDesigner.core.Spacer();
        mainReg.add(spacer2, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        submainReg = new JPanel();
        submainReg.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        submainReg.setBackground(new Color(-1));
        mainReg.add(submainReg, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        stage1 = new JPanel();
        stage1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(3, 1, new Insets(0, 0, 0, 0), -1, -1));
        stage1.setBackground(new Color(-1));
        submainReg.add(stage1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        regtxt = new JPanel();
        regtxt.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        regtxt.setBackground(new Color(-1));
        stage1.add(regtxt, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        lbreg = new JLabel();
        Font lbregFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 36, lbreg.getFont());
        if (lbregFont != null) lbreg.setFont(lbregFont);
        lbreg.setText("Регистрация");
        regtxt.add(lbreg, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btns = new JPanel();
        btns.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 4, new Insets(0, 0, 0, 0), -1, -1));
        btns.setBackground(new Color(-1));
        stage1.add(btns, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        btnNext = new JButton();
        btnNext.setBackground(new Color(-16777216));
        Font btnNextFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 14, btnNext.getFont());
        if (btnNextFont != null) btnNext.setFont(btnNextFont);
        btnNext.setForeground(new Color(-1));
        btnNext.setText("Далее");
        btns.add(btnNext, new com.intellij.uiDesigner.core.GridConstraints(0, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnBack = new JButton();
        btnBack.setBackground(new Color(-16777216));
        Font btnBackFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 14, btnBack.getFont());
        if (btnBackFont != null) btnBack.setFont(btnBackFont);
        btnBack.setForeground(new Color(-1));
        btnBack.setText("Назад");
        btns.add(btnBack, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer3 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer3, new com.intellij.uiDesigner.core.GridConstraints(0, 3, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer4 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer4, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer5 = new com.intellij.uiDesigner.core.Spacer();
        btns.add(spacer5, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        logtxt = new JPanel();
        logtxt.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(6, 1, new Insets(0, 0, 0, 0), -1, -1));
        logtxt.setBackground(new Color(-1));
        stage1.add(logtxt, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        tfPassConfirm = new JPasswordField();
        tfPassConfirm.setBackground(new Color(-1));
        tfPassConfirm.setCaretColor(new Color(-16777216));
        tfPassConfirm.setForeground(new Color(-16777216));
        logtxt.add(tfPassConfirm, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfPassEnter = new JPasswordField();
        tfPassEnter.setBackground(new Color(-1));
        tfPassEnter.setCaretColor(new Color(-16777216));
        tfPassEnter.setForeground(new Color(-16777216));
        logtxt.add(tfPassEnter, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfLogin = new JTextField();
        tfLogin.setBackground(new Color(-1));
        tfLogin.setCaretColor(new Color(-16777216));
        tfLogin.setForeground(new Color(-16777216));
        tfLogin.setInheritsPopupMenu(false);
        tfLogin.setOpaque(true);
        tfLogin.setVisible(true);
        tfLogin.putClientProperty("html.disable", Boolean.FALSE);
        logtxt.add(tfLogin, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        login = new JLabel();
        Font loginFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, login.getFont());
        if (loginFont != null) login.setFont(loginFont);
        login.setText("Логин:");
        logtxt.add(login, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        pass = new JLabel();
        Font passFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, pass.getFont());
        if (passFont != null) pass.setFont(passFont);
        pass.setText("Пароль:");
        logtxt.add(pass, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        confirmpass = new JLabel();
        Font confirmpassFont = this.$$$getFont$$$("JetBrains Mono", Font.BOLD, 16, confirmpass.getFont());
        if (confirmpassFont != null) confirmpass.setFont(confirmpassFont);
        confirmpass.setText("Повторите пароль:");
        logtxt.add(confirmpass, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfPassConfirm.setNextFocusableComponent(btnNext);
        tfPassEnter.setNextFocusableComponent(tfPassEnter);
        tfLogin.setNextFocusableComponent(tfPassConfirm);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return mainReg;
    }

}

