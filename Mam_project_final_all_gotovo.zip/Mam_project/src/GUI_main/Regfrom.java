package GUI_main;

import GUI_helper.ReadFromWeb;
import GUI_helper.User;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Locale;


public class Regfrom extends JFrame {
    private JLabel Register;
    private JLabel reg;
    private JTextField tfName;
    private JTextField tfAge;
    private JTextField tfLogin;
    private JTextField tfAbout;
    private JPasswordField pfPassword;
    private JPasswordField pfConfirmpass;
    private JButton btnRegister;
    private JButton btnCancel;
    private JPanel RegisterPanel;
    private JTextField tfSex;
    private JTextField tfHeight;
    private JTextField tfCity;
    private JTextField tfGoals;

    public User user = new User();

    public Regfrom() {
        setTitle("Create a new account");
        setContentPane(RegisterPanel);
        setMinimumSize(new Dimension(450, 474));
        setVisible(false);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    registerUser();
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                rtrn_main();
            }
        });
    }

    private void rtrn_main(){
        this.dispose();
        loginpage lp = new loginpage();
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        lp.setSize(800, 900);
        int x = (screenSize.width - lp.getWidth()) / 2;
        int y = (screenSize.height - lp.getHeight()) / 2;
        lp.setLocation(x, y);
        lp.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        lp.setVisible(true);
    }
    private void registerUser() throws IOException {
            String name = tfName.getText();
            String login = tfLogin.getText();
            String age = tfAge.getText();
            String password = String.valueOf(pfPassword.getPassword());
            String confirmPassword = String.valueOf(pfConfirmpass.getPassword());
            String height = tfHeight.getText();
            String about = tfAbout.getText();
            Boolean sex = Boolean.valueOf(tfSex.getText());
            String city = tfCity.getText();
            String goals = tfGoals.getText();

            if (name.isEmpty() || about.isEmpty() || login.isEmpty() || age.isEmpty() || password.isEmpty() || height.isEmpty() || city.isEmpty() || goals.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter all fields",
                        "Try again",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(this,
                        "Confirm Password does not match",
                        "Try again",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            int if_log = addUserToDatabase(name, age, login, password, height, about, sex, city, goals);
            System.out.println(if_log);
            if (if_log != 0) {

                user.name = name;
                user.age = Integer.parseInt(age);
                user.login = login;
                user.password = password;
                user.height = height;
                user.about = about;
                user.sex = sex;
                user.city = city;
                user.goals = goals;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Failed to register new user",
                        "Try again",
                        JOptionPane.ERROR_MESSAGE);
            }
        rtrn_main();
    }


    private int addUserToDatabase(String name, String age, String login, String password, String height, String about, Boolean sex, String city, String goals) throws IOException {

        String url = "reg?name=" + URLEncoder.encode(name, "UTF-8") + "&age=" + URLEncoder.encode(age, "UTF-8") + "&log=" + URLEncoder.encode(login, "UTF-8") + "&pwd=" + URLEncoder.encode(password, "UTF-8") + "&hg=" + URLEncoder.encode(height, "UTF-8") + "&ab=" + URLEncoder.encode(about, "UTF-8") + "&sex=" + sex + "&ct=" + URLEncoder.encode(city, "UTF-8") + "&gl=" + URLEncoder.encode(goals, "UTF-8") + "";
        String res = ReadFromWeb.readFromWeb(url);
        System.out.println(res);
        return Integer.parseInt(res);
    }

    public static void main(String[] args) {
        Regfrom myForm = new Regfrom();
        myForm.pack();
        myForm.setVisible(true);

        User user = myForm.user;
        if (user != null) {
            System.out.println("Successful registration of: " + user.name);
        } else {
            System.out.println("Registration canceled");
        }
        System.exit(0);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        RegisterPanel = new JPanel();
        RegisterPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(13, 3, new Insets(0, 0, 0, 0), -1, -1));
        Register = new JLabel();
        Register.setText("Register");
        RegisterPanel.add(Register, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        reg = new JLabel();
        reg.setIcon(new ImageIcon(getClass().getResource("/GUI_main/profile.png")));
        reg.setText("");
        RegisterPanel.add(reg, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_NORTH, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfName = new JTextField();
        tfName.setBackground(new Color(-4473925));
        Font tfNameFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, tfName.getFont());
        if (tfNameFont != null) tfName.setFont(tfNameFont);
        RegisterPanel.add(tfName, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label1 = new JLabel();
        label1.setBackground(new Color(-4473925));
        Font label1Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Name");
        RegisterPanel.add(label1, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label2 = new JLabel();
        label2.setBackground(new Color(-4473925));
        Font label2Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label2.getFont());
        if (label2Font != null) label2.setFont(label2Font);
        label2.setText("Age");
        RegisterPanel.add(label2, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfAge = new JTextField();
        tfAge.setBackground(new Color(-4473925));
        Font tfAgeFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, tfAge.getFont());
        if (tfAgeFont != null) tfAge.setFont(tfAgeFont);
        RegisterPanel.add(tfAge, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 2, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label3 = new JLabel();
        label3.setBackground(new Color(-4473925));
        Font label3Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label3.getFont());
        if (label3Font != null) label3.setFont(label3Font);
        label3.setText("login");
        RegisterPanel.add(label3, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label4 = new JLabel();
        label4.setBackground(new Color(-4473925));
        Font label4Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label4.getFont());
        if (label4Font != null) label4.setFont(label4Font);
        label4.setText("Password");
        RegisterPanel.add(label4, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JLabel label5 = new JLabel();
        label5.setBackground(new Color(-4473925));
        Font label5Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label5.getFont());
        if (label5Font != null) label5.setFont(label5Font);
        label5.setText("about");
        RegisterPanel.add(label5, new com.intellij.uiDesigner.core.GridConstraints(6, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        tfAbout = new JTextField();
        tfAbout.setBackground(new Color(-4473925));
        Font tfAboutFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, tfAbout.getFont());
        if (tfAboutFont != null) tfAbout.setFont(tfAboutFont);
        RegisterPanel.add(tfAbout, new com.intellij.uiDesigner.core.GridConstraints(6, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        pfPassword = new JPasswordField();
        pfPassword.setBackground(new Color(-4473925));
        Font pfPasswordFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, pfPassword.getFont());
        if (pfPasswordFont != null) pfPassword.setFont(pfPasswordFont);
        RegisterPanel.add(pfPassword, new com.intellij.uiDesigner.core.GridConstraints(5, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        final JLabel label6 = new JLabel();
        label6.setBackground(new Color(-4473925));
        Font label6Font = this.$$$getFont$$$("Courier New", Font.BOLD, 16, label6.getFont());
        if (label6Font != null) label6.setFont(label6Font);
        label6.setText("Confirm pass");
        RegisterPanel.add(label6, new com.intellij.uiDesigner.core.GridConstraints(7, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        pfConfirmpass = new JPasswordField();
        pfConfirmpass.setBackground(new Color(-4473925));
        Font pfConfirmpassFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, pfConfirmpass.getFont());
        if (pfConfirmpassFont != null) pfConfirmpass.setFont(pfConfirmpassFont);
        RegisterPanel.add(pfConfirmpass, new com.intellij.uiDesigner.core.GridConstraints(7, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        btnRegister = new JButton();
        btnRegister.setBackground(new Color(-4473925));
        Font btnRegisterFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, btnRegister.getFont());
        if (btnRegisterFont != null) btnRegister.setFont(btnRegisterFont);
        btnRegister.setText("Register");
        RegisterPanel.add(btnRegister, new com.intellij.uiDesigner.core.GridConstraints(12, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        btnCancel = new JButton();
        btnCancel.setBackground(new Color(-4473925));
        Font btnCancelFont = this.$$$getFont$$$("Courier New", Font.BOLD, 16, btnCancel.getFont());
        if (btnCancelFont != null) btnCancel.setFont(btnCancelFont);
        btnCancel.setText("Cancel");
        RegisterPanel.add(btnCancel, new com.intellij.uiDesigner.core.GridConstraints(12, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        RegisterPanel.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(8, 0, 2, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        tfLogin = new JTextField();
        RegisterPanel.add(tfLogin, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfSex = new JTextField();
        RegisterPanel.add(tfSex, new com.intellij.uiDesigner.core.GridConstraints(9, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfHeight = new JTextField();
        RegisterPanel.add(tfHeight, new com.intellij.uiDesigner.core.GridConstraints(8, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfCity = new JTextField();
        RegisterPanel.add(tfCity, new com.intellij.uiDesigner.core.GridConstraints(10, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
        tfGoals = new JTextField();
        RegisterPanel.add(tfGoals, new com.intellij.uiDesigner.core.GridConstraints(11, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, new Dimension(150, -1), null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return RegisterPanel;
    }
}
